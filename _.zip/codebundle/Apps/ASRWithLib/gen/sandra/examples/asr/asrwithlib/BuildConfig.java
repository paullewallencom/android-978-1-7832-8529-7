/** Automatically generated file. DO NOT MODIFY */
package sandra.examples.asr.asrwithlib;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}