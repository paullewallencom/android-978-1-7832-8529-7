/** Automatically generated file. DO NOT MODIFY */
package sandra.examples.multilingual.parrot;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}