/** Automatically generated file. DO NOT MODIFY */
package sandra.examples.tss.ttswithintent;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}