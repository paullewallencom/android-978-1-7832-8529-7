/** Automatically generated file. DO NOT MODIFY */
package sandra.examples.nlu.grammartest;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}