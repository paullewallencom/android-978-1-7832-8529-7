/** Automatically generated file. DO NOT MODIFY */
package sandra.examples.vpa.stacy;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}