/** Automatically generated file. DO NOT MODIFY */
package sandra.libs.asr.asrlib;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}