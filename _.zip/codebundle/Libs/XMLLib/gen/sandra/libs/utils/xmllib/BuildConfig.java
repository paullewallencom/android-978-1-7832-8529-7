/** Automatically generated file. DO NOT MODIFY */
package sandra.libs.utils.xmllib;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}