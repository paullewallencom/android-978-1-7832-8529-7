Thank you for your interest in this book!

This is the last update of the code at the time of publication, 
but we would really appreciate to hear your suggestions and ideas 
on our Web page: 

http://lsi.ugr.es/zoraida/androidspeechbook

We will take account of your feedback and also publish new materials 
in our github repository, so if you want to access the 
LATEST VERSION OF THE CODE just go to: 

https://github.com/zoraidacallejas/sandra

Have fun!